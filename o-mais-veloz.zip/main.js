const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 0 },
            debug: false
        }
    },
    scene: {
        preload: preload,
        create: create,
        update: update
    }
};

let player;
let cursors;
let coins;
let score = 0;
let scoreText;

const game = new Phaser.Game(config);

function preload () {
    this.load.image('car', 'car.png');
    this.load.image('coin', 'coin.png');
    this.load.image('road', 'road.png');
}

function create () {
    this.add.tileSprite(400, 300, 800, 600, 'road');
    
    player = this.physics.add.sprite(400, 300, 'car');
    player.setCollideWorldBounds(true);
    
    coins = this.physics.add.group({
        key: 'coin',
        repeat: 10,
        setXY: { x: 50, y: 50, stepX: 70 }
    });

    this.physics.add.overlap(player, coins, collectCoin, null, this);

    scoreText = this.add.text(16, 16, 'Olimpo: 0', { fontSize: '24px', fill: '#000' });

    cursors = this.input.keyboard.createCursorKeys();
}

function update () {
    player.setVelocity(0);
    
    if (cursors.left.isDown) {
        player.setVelocityX(-200);
    } else if (cursors.right.isDown) {
        player.setVelocityX(200);
    }

    if (cursors.up.isDown) {
        player.setVelocityY(-200);
    } else if (cursors.down.isDown) {
        player.setVelocityY(200);
    }
}

function collectCoin (player, coin) {
    coin.disableBody(true, true);
    score += 10;
    scoreText.setText('Olimpo: ' + score);
}
